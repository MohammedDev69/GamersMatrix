import { StoreShell } from "@/components/layout/StoreShell";
import { SearchHero } from "@/components/home/SearchHero";
import { ProductSection } from "@/components/home/ProductSection";
import { CategoryStrip } from "@/components/home/CategoryStrip";
import { TrustBar } from "@/components/home/TrustBar";

export default function HomePage() {
  return (
    <StoreShell>
      <SearchHero />
      <CategoryStrip />
      <ProductSection
        titleKey="featured"
        query={{ featured: true, sort: "popular" }}
        viewAllHref="/shop?sort=popular"
      />
      <ProductSection
        titleKey="newReleases"
        query={{ isNew: true, sort: "newest" }}
        viewAllHref="/shop?filter=new&sort=newest"
      />
      <ProductSection
        titleKey="offers"
        query={{ weeklyDeal: true, sort: "popular" }}
        viewAllHref="/offers"
      />
      <ProductSection
        titleKey="directTopUp"
        query={{ kind: "TOP_UP", sort: "popular" }}
        viewAllHref="/top-ups"
      />
      <TrustBar />
    </StoreShell>
  );
}
