"use client";

import { useEffect, useState } from "react";
import { useLocale, useTranslations } from "next-intl";
import { Link } from "@/i18n/navigation";
import type { Product } from "@/lib/api";
import { listProducts, type CatalogQuery } from "@/lib/catalog/repository";
import { ProductCard } from "@/components/products/ProductCard";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { Skeleton } from "@/components/ui/Skeleton";

type TitleKey =
  | "featured"
  | "newReleases"
  | "offers"
  | "popular"
  | "steamGames"
  | "directTopUp";

type Props = {
  titleKey: TitleKey;
  query: CatalogQuery;
  viewAllHref: string;
};

export function ProductSection({ titleKey, query, viewAllHref }: Props) {
  const t = useTranslations("Home");
  const locale = useLocale();
  const [items, setItems] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  const queryKey = JSON.stringify(query);

  useEffect(() => {
    setLoading(true);
    const parsed = JSON.parse(queryKey) as CatalogQuery;
    listProducts({ ...parsed, lang: locale, pageSize: 12, limit: 12 })
      .then((res) => setItems(res.items.slice(0, 12)))
      .catch(() => setItems([]))
      .finally(() => setLoading(false));
  }, [queryKey, locale]);

  return (
    <section className="gm-container py-8 md:py-10">
      <SectionHeading
        title={t(titleKey)}
        action={
          <Link
            href={viewAllHref}
            className="text-sm font-medium text-[var(--gm-violet-300)] hover:underline"
          >
            {t("viewAll")}
          </Link>
        }
      />
      {loading ? (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton
              key={i}
              className="aspect-[3/4] w-full rounded-[var(--gm-radius-card)]"
            />
          ))}
        </div>
      ) : items.length === 0 ? null : (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
          {items.map((product, i) => (
            <ProductCard key={product.id} product={product} index={i} />
          ))}
        </div>
      )}
    </section>
  );
}
