"use client";

import Image from "next/image";
import { useState, type MouseEvent } from "react";
import { Heart } from "lucide-react";
import { useLocale, useTranslations } from "next-intl";
import { Link, useRouter } from "@/i18n/navigation";
import type { Product } from "@/lib/api";
import { useCurrency } from "@/lib/currency";
import { useWishlist } from "@/lib/wishlist";
import { getValidSale, isOutOfStock } from "@/lib/pricing";
import { PRODUCT_ART_PLACEHOLDER } from "@/lib/catalog/fixtures";
import { Badge } from "@/components/ui/Badge";
import { cn } from "@/lib/cn";

type Props = {
  product: Product;
  index?: number;
};

function kindLabel(
  kind: Product["kind"],
  t: ReturnType<typeof useTranslations<"Catalog">>,
) {
  if (kind === "TOP_UP") return t("directTopUps");
  if (kind === "GIFT_CARD") return t("giftCard");
  if (kind === "SERVICE") return t("service");
  return t("gameKey");
}

export function ProductCard({ product, index = 0 }: Props) {
  const t = useTranslations("Catalog");
  const tNav = useTranslations("Nav");
  const locale = useLocale();
  const { formatPrice } = useCurrency();
  const { isWishlisted, toggle } = useWishlist();
  const router = useRouter();
  const [src, setSrc] = useState(product.imageUrl);
  const [failed, setFailed] = useState(false);
  const [wishBusy, setWishBusy] = useState(false);
  const outOfStock = isOutOfStock(product);
  const sale = getValidSale(product);
  const wished = isWishlisted(product.id);

  async function onWishlist(e: MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    if (wishBusy) return;
    setWishBusy(true);
    try {
      const result = await toggle(product.id);
      if (result === "login") router.push("/login");
    } catch {
      /* keep UI stable */
    } finally {
      setWishBusy(false);
    }
  }

  return (
    <article
      className="gm-reveal group flex flex-col"
      style={{ transitionDelay: `${Math.min(index, 11) * 40}ms` }}
    >
      <div className="relative">
        <Link
          href={`/products/${product.slug}`}
          className="relative block aspect-[3/4] overflow-hidden rounded-[var(--gm-radius-card)] bg-[var(--gm-surface)] ring-1 ring-[var(--gm-border)] transition duration-200 group-hover:ring-[var(--gm-border-strong)] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--gm-violet-500)]"
        >
          {failed ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={PRODUCT_ART_PLACEHOLDER}
              alt=""
              className="absolute inset-0 h-full w-full object-cover"
            />
          ) : (
            <Image
              src={src}
              alt={product.title}
              fill
              className="object-cover transition duration-300 group-hover:scale-[1.03]"
              sizes="(max-width:768px) 50vw, 16vw"
              onError={() => {
                setFailed(true);
                setSrc(PRODUCT_ART_PLACEHOLDER);
              }}
            />
          )}
          {failed ? (
            <span className="absolute inset-x-2 bottom-3 text-center text-xs font-semibold text-[var(--gm-violet-300)]">
              {product.title}
            </span>
          ) : null}

          <div className="absolute start-2 top-2 flex flex-wrap gap-1">
            {product.isNew ? <Badge tone="info">{t("new")}</Badge> : null}
            {sale.discountPct ? (
              <Badge tone="danger">-{sale.discountPct}%</Badge>
            ) : null}
            {outOfStock ? (
              <Badge tone="neutral">{t("outOfStock")}</Badge>
            ) : null}
          </div>
        </Link>

        <button
          type="button"
          onClick={onWishlist}
          disabled={wishBusy}
          aria-pressed={wished}
          aria-label={tNav("wishlist")}
          className={cn(
            "absolute end-2 top-2 inline-flex h-10 w-10 items-center justify-center rounded-[var(--gm-radius-btn)] border border-[var(--gm-border)] bg-[var(--gm-bg-raised)]/90 text-[var(--gm-text-secondary)] backdrop-blur transition-colors",
            "hover:text-[var(--gm-violet-300)] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--gm-violet-500)]",
            wished && "text-[var(--gm-violet-400)]",
          )}
        >
          <Heart
            className="h-4 w-4"
            fill={wished ? "currentColor" : "none"}
            aria-hidden
          />
        </button>
      </div>

      <div className="space-y-1 px-0.5 pt-3">
        <p className="text-[11px] font-medium text-[var(--gm-text-secondary)]">
          <span dir="ltr">{product.platform}</span>
          {" · "}
          {kindLabel(product.kind, t)}
        </p>
        <Link
          href={`/products/${product.slug}`}
          className="line-clamp-2 text-sm font-semibold leading-snug text-[var(--gm-text)] transition group-hover:text-[var(--gm-violet-300)]"
        >
          <span dir="auto">{product.title}</span>
        </Link>
        <div
          className="flex items-baseline gap-2"
          dir={locale === "ar" ? "rtl" : "ltr"}
        >
          <span className="text-base font-bold tabular-nums text-[var(--gm-text)]">
            {formatPrice(sale.current)}
          </span>
          {sale.compareAt ? (
            <span className="text-xs text-[var(--gm-text-muted)] line-through tabular-nums">
              {formatPrice(sale.compareAt)}
            </span>
          ) : null}
        </div>
      </div>
    </article>
  );
}
