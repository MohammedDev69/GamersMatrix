"use client";

import { ReactNode } from "react";
import { useTranslations } from "next-intl";
import { Header } from "./Header";
import { Footer } from "./Footer";
import { WhatsAppFab } from "./WhatsAppFab";
import { NavRail } from "./NavRail";

type StoreShellProps = {
  children: ReactNode;
};

export function StoreShell({ children }: StoreShellProps) {
  const t = useTranslations("Common");

  return (
    <div className="relative flex min-h-screen flex-col overflow-x-hidden text-[var(--gm-text)]">
      <a href="#main-content" className="gm-skip-link">
        {t("skipToContent")}
      </a>
      <div className="gm-bg" aria-hidden="true" />
      <Header />
      <NavRail />
      <main
        id="main-content"
        className="flex-1 lg:pl-[var(--gm-rail-width)] xl:pl-[var(--gm-rail-width-expanded)]"
        tabIndex={-1}
      >
        {children}
      </main>
      <div className="lg:pl-[var(--gm-rail-width)] xl:pl-[var(--gm-rail-width-expanded)]">
        <Footer />
      </div>
      <WhatsAppFab />
    </div>
  );
}
