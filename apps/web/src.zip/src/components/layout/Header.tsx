"use client";

import { FormEvent, Suspense, useState } from "react";
import {
  Heart,
  LayoutDashboard,
  LogIn,
  LogOut,
  Menu,
  ShoppingCart,
  User,
} from "lucide-react";
import { useTranslations } from "next-intl";
import { Link, useRouter } from "@/i18n/navigation";
import { useAuth } from "@/lib/auth";
import { useCart } from "@/lib/cart";
import { cn } from "@/lib/cn";
import { SearchField } from "@/components/ui/SearchField";
import { IconButton } from "@/components/ui/IconButton";
import { Button } from "@/components/ui/Button";
import { MobileNav, TopNav } from "./TopNav";
import { CurrencySwitcher } from "./CurrencySwitcher";
import { LocaleSwitcher } from "./LocaleSwitcher";

const headerLinkIcon =
  "inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-[var(--gm-radius-btn)] text-[var(--gm-text-secondary)] transition-colors duration-150 hover:bg-[var(--gm-surface-hover)] hover:text-[var(--gm-text)] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--gm-violet-500)]";

export function Header() {
  const t = useTranslations("Nav");
  const tBrand = useTranslations("Brand");
  const tCommon = useTranslations("Common");
  const { user, logout } = useAuth();
  const { count } = useCart();
  const router = useRouter();
  const [q, setQ] = useState("");
  const [mobileOpen, setMobileOpen] = useState(false);

  function onSearch(value: string) {
    const query = value.trim();
    router.push(
      query ? `/search?q=${encodeURIComponent(query)}` : "/search",
    );
  }

  function onSearchSubmit(e: FormEvent) {
    e.preventDefault();
    onSearch(q);
  }

  return (
    <header className="sticky top-0 z-40 px-3 pt-3 lg:pl-[calc(var(--gm-rail-width)+0.75rem)] xl:pl-[calc(var(--gm-rail-width-expanded)+0.75rem)]">
      <div className="gm-header mx-auto max-w-[1400px] px-3 md:px-5">
        <div className="flex h-16 items-center gap-3">
          <IconButton
            label={t("menu")}
            className="lg:hidden"
            onClick={() => setMobileOpen(true)}
          >
            <Menu className="h-5 w-5" />
          </IconButton>

          <Link
            href="/"
            className="gm-display group flex shrink-0 items-center gap-2.5 text-lg font-extrabold text-[var(--gm-text)]"
          >
            <span className="flex h-9 w-9 items-center justify-center rounded-[var(--gm-radius-btn)] bg-[var(--gm-cta-gradient)] text-sm shadow-[var(--gm-shadow-glow)] transition duration-200 group-hover:brightness-110">
              <span aria-hidden>M</span>
            </span>
            <span className="hidden sm:inline" aria-hidden>
              <span className="text-[var(--gm-text)]">GAMERS </span>
              <span className="text-[var(--gm-violet-400)]">MATRIX</span>
            </span>
            <span className="sr-only">{tBrand("name")}</span>
          </Link>

          <div className="mx-auto min-w-0 flex-1 md:max-w-md lg:mx-0 lg:max-w-sm xl:max-w-md">
            <form onSubmit={onSearchSubmit} className="hidden md:block">
              <SearchField
                label={t("search")}
                clearLabel={tCommon("close")}
                value={q}
                onChange={(e) => setQ(e.target.value)}
                onClear={() => setQ("")}
                onSubmitSearch={onSearch}
                placeholder={t("search")}
                className="w-full"
              />
            </form>
          </div>

          <div className="ms-auto flex shrink-0 items-center gap-0.5">
            <Suspense fallback={null}>
              <LocaleSwitcher />
            </Suspense>
            <CurrencySwitcher />
            <Link
              href="/wishlist"
              className={headerLinkIcon}
              aria-label={t("wishlist")}
            >
              <Heart className="h-5 w-5" />
            </Link>
            <Link
              href="/cart"
              className={cn(headerLinkIcon, "relative")}
              aria-label={t("cart")}
            >
              <ShoppingCart className="h-5 w-5" />
              {count > 0 ? (
                <span
                  key={count}
                  className="gm-animate-badge absolute -top-0.5 -start-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-[var(--gm-violet-600)] px-1 text-[10px] font-bold text-white"
                >
                  {count}
                </span>
              ) : null}
            </Link>
            {user ? (
              <div className="flex items-center gap-0.5">
                {user.role === "ADMIN" ? (
                  <Link
                    href="/admin"
                    className="hidden items-center gap-1.5 rounded-[var(--gm-radius-btn)] bg-[var(--gm-accent-dim)] px-3 py-2 text-sm font-semibold text-[var(--gm-violet-300)] ring-1 ring-[var(--gm-violet-700)] transition hover:bg-[var(--gm-violet-700)] hover:text-white sm:flex"
                  >
                    <LayoutDashboard className="h-4 w-4" />
                    {t("admin")}
                  </Link>
                ) : null}
                <Link
                  href="/account"
                  className="hidden items-center gap-1.5 rounded-[var(--gm-radius-btn)] px-3 py-2 text-sm text-[var(--gm-text)] hover:bg-[var(--gm-surface-hover)] sm:flex"
                >
                  <User className="h-4 w-4" />
                  <span className="max-w-[80px] truncate">{user.name}</span>
                </Link>
                <IconButton
                  label={t("logout")}
                  onClick={() => {
                    logout();
                    router.push("/");
                  }}
                >
                  <LogOut className="h-4 w-4" />
                </IconButton>
              </div>
            ) : (
              <Link href="/login">
                <Button
                  variant="primary"
                  className="!min-h-10 !px-4 !py-2 text-sm"
                >
                  <LogIn className="h-4 w-4 sm:hidden" />
                  <span className="hidden sm:inline">{t("login")}</span>
                </Button>
              </Link>
            )}
          </div>
        </div>

        <div className="border-t border-[var(--gm-border)] py-2 lg:hidden">
          <Suspense fallback={<div className="h-9" />}>
            <TopNav />
          </Suspense>
        </div>
      </div>

      <Suspense fallback={null}>
        <MobileNav open={mobileOpen} onClose={() => setMobileOpen(false)} />
      </Suspense>
    </header>
  );
}
